import tkinter as tk
import random
from tkinter import messagebox
from tkinter.ttk import Label

from PIL import Image, ImageTk

#随机数字决定壁纸
# background_number = random.randint(1,34)

#窗口之类的设置
MayOSDesktop = tk.Tk()#创建窗口
MayOSDesktop.title("MayOS_GUI")#hell title

#弹出窗口测试
#顺便测试一下图片显示,{pic on text}
test_image = Image.open("files/background/default.jpg")#load fuck picture
test_image = test_image.resize((1280,720))#resize the pic
test_image = ImageTk.PhotoImage(test_image)#wtf,idn
test_label = Label(MayOSDesktop, image = test_image, justify="center")
test_label.configure(compound="top")
test_label.pack(side="bottom")
messagebox.showerror("test", message="this is a f**k message")

#设置窗口大小
MayOSDesktop.geometry("1280x720")

#主循环
MayOSDesktop.mainloop()